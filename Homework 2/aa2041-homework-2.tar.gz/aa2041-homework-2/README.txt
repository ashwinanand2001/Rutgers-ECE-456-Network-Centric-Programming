
Name: Ashwin Anand
Net ID:  aa2041
RUID: 192007894
Class: Network Centric Programming
Assignment:  Homework 2

Description: 
The code that can be seen in homework2.c is my solution to identify the summation result of numbers from 1 to 100 across 4 different threads. The code contains 5 methods in which there are 4 thread methods and 1 main method. The code has error statements to catch whether a thread has not been created. There are print statements to show what each thread sum is to be before they are all added together for the global sum. The output will be sum of thread 1 + sum of thread 2 + sum of thread 3 + sum of thread 4.