
Name: Ashwin Anand
Net ID:  aa2041
RUID: 192007894
Class: Network Centric Programming
Assignment:  Homework 1

Description: 
The code that can be seen in homework1.c is my solution to identify the summation result of numbers from 1 to 100 across 3 processes. The code contains 2 fork statement to create child processes that were  created. So there are 3 processes in total. If the child process is not created successfully, then there are errors produced. Three loops are written to sum up each processes, then there is a final summation into a total variable. Regarding output, the sum result from each process along with the process id is printed and then also the total of all the three processes is also printed. 