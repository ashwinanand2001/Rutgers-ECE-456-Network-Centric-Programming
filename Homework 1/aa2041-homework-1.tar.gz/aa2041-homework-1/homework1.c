
// Ashwin Anand RUID: 192007894 Net Id: aa2041

// Packages needed for program to run
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>



// main method of program
int main()
{
	// sum variables created and value of 0 assigned
	int sum_of_loop_1 = 0;
	int sum_of_loop_2 = 0;
	int sum_of_loop_3 = 0;

	// initalizing fd to 2 for reading and writing
	int file_directory[2];

	// pipe command usage to allow sum and process pid's to be allowed to use sequentially
	pipe(file_directory);

	// making a pid process value 1 and making child process through fork  command
	pid_t pid_process_1 = fork();

	// if loop to make sure that child process was created and if no process was created issue an error
	if(pid_process_1<0)
	{
		// error message
		perror("Process creation failed");
	}
	// checking to see if the pid_process_1 is 0 then its considered to be the child process
	else if(pid_process_1 == 0)
	{
		// for  loop  to add 1 through 33 to itself and value is allocated to sum_of_loop_1
		for(int a = 1; a <= 33; a++)
		{
			sum_of_loop_1 += a;
		}

		// print statement to print outprocess id and value of 1 to 33 from first process
		printf("The process pid for the summation of 1 to 33 is %d and the summation of 1 to 33 is calculated to be %d\n", (int) getpid(), sum_of_loop_1);

		// write function tells the system the location of the output to show
		write(file_directory[1], &sum_of_loop_1, sizeof(sum_of_loop_1));
	}

	// goes into else loop as the pid_process_1 is a parent process not a child process
	else
	{
		// making a pid process value 2 and making child process through fork  command
		pid_t pid_process_2 = fork();

	    // if loop to make sure that child process was created and if no process was created issue an error
		if(pid_process_2<0)
		{
			// error message
			perror("Process creation failed");
		}

		// checking to see if the pid_process_1 is 0 then its considered to be the child process
		else if(pid_process_2 == 0)
		{
			// for  loop  to add 34 through 67 to itself and value is allocated to sum_of_loop_2
			for(int b = 34; b <= 67; b++)
			{
				sum_of_loop_2 += b;
			}

			// print statement to print outprocess id and value of 34 to 67 from first process
			printf("The process pid for the summation of 34 to 67 is %d and the summation of 34 to 67 is calculated to be %d\n", (int) getpid(), sum_of_loop_2);

			// write function tells the system the location of the output to show
			write(file_directory[1], &sum_of_loop_2, sizeof(sum_of_loop_2));
		}

		else
		{
			// read function attempts to read bytes from the sum_of_loop_1 file
			read(file_directory[0], &sum_of_loop_1, sizeof(sum_of_loop_1));

			// for  loop  to add 34 through 67 to itself and value is allocated to sum_of_loop_2
			for(int c = 68; c <= 100; c++)
			{
				sum_of_loop_3 += c;
			}

			// print statement to print outprocess id and value of 68 to 100 from first process
			printf("The process pid for the summation of 68 to 100 is %d and the summation of 68 to 100 is calculated to be %d\n", (int) getpid(), sum_of_loop_3);

			// read function attempts to read bytes from the sum_of_loop_2 file
			read(file_directory[0], &sum_of_loop_2, sizeof(sum_of_loop_2));

			// total will contain the values of sum_of_loop_1, sum_of_loop_2, sum_of_loop_3 added up
			int total = sum_of_loop_1 + sum_of_loop_2 + sum_of_loop_3;

			// print statement to show the value of total_sum for 1 to 100 summation of n
			printf("The summation of all processes from 1 to 100 is %d\n", total);
		}
	}
}
